import java.io.InputStream;
import java.io.OutputStream;

import com.virtenio.driver.adc.ADCException;
import com.virtenio.driver.adc.NativeADC;
import com.virtenio.driver.can.CANException;
import com.virtenio.driver.can.NativeCAN;
import com.virtenio.driver.device.ADT7410;
import com.virtenio.driver.device.ADXL345;
import com.virtenio.driver.device.BH1710FVC;
import com.virtenio.driver.device.MPL115A2;
import com.virtenio.driver.device.SHT21;
import com.virtenio.driver.device.at86rf231.AT86RF231;
import com.virtenio.driver.device.at86rf231.AT86RF231RadioDriver;
import com.virtenio.driver.flash.Flash;
import com.virtenio.driver.flash.FlashException;
import com.virtenio.driver.gpio.GPIO;
import com.virtenio.driver.gpio.GPIOException;
import com.virtenio.driver.gpio.NativeGPIO;
import com.virtenio.driver.i2c.I2C;
import com.virtenio.driver.i2c.I2CException;
import com.virtenio.driver.i2c.NativeI2C;
import com.virtenio.driver.irq.IRQException;
import com.virtenio.driver.ram.NativeRAM;
import com.virtenio.driver.ram.RAMException;
import com.virtenio.driver.spi.NativeSPI;
import com.virtenio.driver.spi.SPIException;
import com.virtenio.driver.usart.NativeUSART;
import com.virtenio.driver.usart.USART;
import com.virtenio.driver.usart.USARTException;
import com.virtenio.driver.usart.USARTParams;
import com.virtenio.misc.PropertyHelper;
import com.virtenio.preon32.examples.common.USARTConstants;
import com.virtenio.preon32.node.Node;
import com.virtenio.radio.RadioDriverException;
import com.virtenio.radio.ieee_802_15_4.FrameIO;
import com.virtenio.radio.ieee_802_15_4.RadioDriver;
import com.virtenio.radio.ieee_802_15_4.RadioDriverFrameIO;
import com.virtenio.vm.Time;

public class BaseStation {

	private final static int BASE_ADDR = PropertyHelper.getInt("local.addr", 0xBABE);
	private final static int COMMON_PANID = PropertyHelper.getInt("radio.panid", 0xCACE);
	private static int input;
	private static USART usart;
	private static OutputStream outStream;
	private static InputStream inStream;

	private static Flash flash;
	private static int sizeFlash;

	private static int address;

	public static void main(String[] args) throws Exception {
		BaseStation.useUSART();
//		BaseStation.out = usart.getOutputStream();

		new Thread() {
			public void run() {
				BaseStation.runs();
			}
		}.start();
	}

	public static void runs() {
		try {
			AT86RF231 t = Node.getInstance().getTransceiver();
			t.open();
			t.setAddressFilter(COMMON_PANID, BASE_ADDR, BASE_ADDR, false);
			final RadioDriver radio = new AT86RF231RadioDriver(t);

			final FrameIO fio = new RadioDriverFrameIO(radio);

			Thread thread = new Thread() {
				public void run() {
					try {
						send(fio);
					} catch (Exception e) {
					}
				}
			};
			thread.start();
		} catch (Exception e) {
		}
	}

	public static void send(final FrameIO fio) throws Exception {
		new Thread() {
			public void run() {
				while (BaseStation.usart != null) {
					try {
						BaseStation.input = usart.read();
						System.out.println("Input yang terbaca : " + BaseStation.input);
//						if (BaseStation.input != 0) {
						if (BaseStation.input == 1) {
							// inisialisasi flash
							BaseStation.flash = Node.getInstance().getFlash();
							BaseStation.flash.open();
							BaseStation.eraseChip();
							BaseStation.sizeFlash = BaseStation.flash.getChipSize();
							BaseStation.flash.close();

							BaseStation.address = 0;

							String msg = "Berhasil connect ke basestation";
							System.out.println(msg);

						} else if (BaseStation.input == 2) {
							BaseStation.flash.open();

							BaseStation.outStream = flash.getOutputStream(address);
							BaseStation.inStream = flash.getInputStream(address);

							System.out.println("Chip Size awal : " + BaseStation.sizeFlash);

							int length = usart.read();
							byte[] in = BaseStation.read(length);

							String msg = new String(in, "UTF-8");
							System.out.println("Data untuk dikirim : \n" + msg);

							// Write With No Erase
							outStream.write(in);

							// Read
							byte[] res = new byte[length];
							inStream.read(res);

							System.out.println("Data yang dibaca dari flash : \n" + new String(res));

							BaseStation.sizeFlash -= length;

							System.out.println("Chip Size akhir : " + BaseStation.sizeFlash);

							BaseStation.address += length;

							BaseStation.flash.close();

						} else if (BaseStation.input == 3) {
							String msg = BaseStation.getKomponen();
							System.out.println(msg);
						} else if (BaseStation.input == 4) {
							BaseStation.sensorSuhu();
						} else if (BaseStation.input == 5) {
							BaseStation.sensorTekananUdara();
						} else if (BaseStation.input == 6) {
							BaseStation.sensorKelembabanUdara();
						} else if (BaseStation.input == 7) {
							BaseStation.sensorGetaran();
						} else if (BaseStation.input == 8) {
							BaseStation.sensorIntensitasCahaya();
						}
						Thread.sleep(3000);
//						}

					} catch (Exception e) {
					}
				}
			};
		}.start();
	}

	/**
	 * Method untuk membaca tiap baris yang dikirimkan oleh program
	 * 
	 * @param length panjang kalimat
	 * @return array of byte, hasil convert string ke array of bytes yang diterima
	 * @throws USARTException
	 */
	private static byte[] read(int length) throws USARTException {
		byte[] res = new byte[length];
		for (int i = 0; i < length; i++) {
			res[i] = (byte) usart.read();
		}

		return res;
	}

	public static void eraseChip() throws FlashException {
		System.out.println("Erase chip");
		long start = Time.millis();
		BaseStation.flash.eraseChip();
		BaseStation.flash.waitWhileBusy();
		long end = Time.millis();
		System.out.println("Erased. Time: " + (end - start));
	}

	// Method untuk mendapatkan Kapasitas RAM
	public static String getKomponen() throws SPIException, GPIOException, RadioDriverException, IRQException,
			ADCException, CANException, I2CException, RAMException, FlashException {

		NativeCAN can = NativeCAN.getInstance(0);
		can.open(BASE_ADDR);

		NativeI2C i2c = NativeI2C.getInstance(1);
		i2c.open(I2C.DATA_RATE_400);

		ADT7410 temp = new ADT7410(i2c, ADT7410.ADDR_0, null, null);
		temp.open();
		temp.setMode(ADT7410.CONFIG_MODE_CONTINUOUS);

		String msg = "";
		msg = "Komponen Preon32 yang tersedia : " + "\n" + BaseStation.getMemoryFlash() + BaseStation.getRAM()
				+ BaseStation.getChannel() + BaseStation.getSizeFlashAvailabke();
		return msg;

	}

	// Method untuk mendapatkan Kapasitas Memori Flash
	public static String getMemoryFlash() throws FlashException, SPIException, GPIOException {
		BaseStation.flash.open();
		String msg = "Data Memory Flash : " + BaseStation.flash.getChipSize() + " Byte" + "\n";
		System.out.println("hasil =" + msg);
		BaseStation.flash.close();
		return msg;
	}

	public static String getSizeFlashAvailabke() {
		String msg = "Data Memory Flash yang tersedia : " + BaseStation.sizeFlash + " Byte" + "\n";
		return msg;
	}

	public static String getRAM() throws RAMException {
		NativeRAM ram = NativeRAM.getInstance(0);
		String msg = "System Memory : " + ram.getSize() + " kByte SRAM" + "\n";
		return msg;
	}

	public static String getChannel() throws ADCException, SPIException, IRQException, RadioDriverException {
		NativeADC adc = NativeADC.getInstance(0);

//			adc.open();
		String msg = "Channels : " + adc.getChannelCount() + "\n" + "test : ";
		return msg;
	}

	public static void useUSART() throws Exception {
		usart = configUSART();
	}

	public static void sensorSuhu() throws I2CException, InterruptedException {
		// Inisialisasi I2C untuk bus
		NativeI2C i2c = NativeI2C.getInstance(1);
		i2c.open(I2C.DATA_RATE_400);

		// inisialisasi modul untuk sensor suhu
		ADT7410 temperatureSensor = new ADT7410(i2c, ADT7410.ADDR_0, null, null);
		temperatureSensor.setMode(ADT7410.CONFIG_MODE_CONTINUOUS);// set continuous mode

		while (BaseStation.input == 4) {
			float celsius = temperatureSensor.getTemperatureCelsius();// membaca suhu
			System.out.println("Suhu saat ini: " + celsius + " [�C]");// print kelayar
			Thread.sleep(1000);
		}
		i2c.close();
	}

	public static void sensorTekananUdara() throws I2CException, GPIOException, InterruptedException {
		NativeI2C i2c = NativeI2C.getInstance(1);
		i2c.open(I2C.DATA_RATE_400);
		GPIO resetPin = NativeGPIO.getInstance(24);
		GPIO shutDownPin = NativeGPIO.getInstance(12);

		MPL115A2 pressureSensor = new MPL115A2(i2c, resetPin, shutDownPin);
		pressureSensor.setReset(false);
		pressureSensor.setShutdown(false);

		while (BaseStation.input == 5) {
			// capture measured value every 1000ms
			pressureSensor.startBothConversion();
			Thread.sleep(MPL115A2.BOTH_CONVERSION_TIME);
			int pressurePr = pressureSensor.getPressureRaw();
			System.out.println("Tekanan udara = " + pressurePr);
			Thread.sleep(1000 - MPL115A2.BOTH_CONVERSION_TIME);
		}
		i2c.close();
	}

	public static void sensorKelembabanUdara() throws I2CException, InterruptedException {
		NativeI2C i2c = NativeI2C.getInstance(1);
		i2c.open(I2C.DATA_RATE_400);

		SHT21 sht21 = new SHT21(i2c);
		sht21.setResolution(SHT21.RESOLUTION_RH12_T14);
		sht21.reset();

		Thread.sleep(1000);
		while (BaseStation.input == 6) {
			sht21.startRelativeHumidityConversion();
			Thread.sleep(100);
			int rawRH = sht21.getRelativeHumidityRaw();
			float rh = SHT21.convertRawRHToRHw(rawRH);
			System.out.println("Kelembaban udara (RH) = " + rh);
			Thread.sleep(900);
		}
		i2c.close();
	}

	private static void sensorGetaran() throws SPIException, GPIOException, InterruptedException {
		NativeSPI spi = NativeSPI.getInstance(2);
		spi.close();
		spi.open(ADXL345.SPI_MODE, ADXL345.SPI_BIT_ORDER, ADXL345.SPI_MAX_SPEED);

		GPIO accelCs = NativeGPIO.getInstance(20);
		ADXL345 accelerationSensor = new ADXL345(spi, accelCs);
		accelerationSensor.setDataFormat(ADXL345.DATA_FORMAT_RANGE_2G);
		accelerationSensor.setDataRate(ADXL345.DATA_RATE_3200HZ);
		accelerationSensor.setPowerControl(ADXL345.POWER_CONTROL_MEASURE);

		while (BaseStation.input == 7) {
			short[] ch = new short[3];
			int offset = 0;
			accelerationSensor.getValuesRaw(ch, offset);
			System.out.println("Acceleration " + "CH[0]:" + ch[0] + " " + "CH[1]:" + ch[1] + " " + "CH[2]:" + ch[2]);
			Thread.sleep(1000);
		}

	}

	private static void sensorIntensitasCahaya() throws I2CException, GPIOException, InterruptedException {
		NativeGPIO dvi = NativeGPIO.getInstance(10);

		NativeI2C i2c = NativeI2C.getInstance(1);
		i2c.open(I2C.DATA_RATE_400);

		BH1710FVC lightsensor = new BH1710FVC(i2c, BH1710FVC.ADDR_L, dvi);
		lightsensor.enable(true);
		
		while (BaseStation.input == 8) {
			int raw = lightsensor.getValueLx();
			int lx = BH1710FVC.convertRawToLx(raw);
			System.out.println("BH1710FVC: raw=" + raw + "; " + lx + " [lx]");
			Thread.sleep(1000);
		}
	}

	private static USART configUSART() {
		int instanceID = 0;
		USARTParams params = USARTConstants.PARAMS_115200;
		NativeUSART usart = NativeUSART.getInstance(instanceID);
		try {
			usart.close();
			usart.open(params);
			return usart;
		} catch (Exception e) {
			return null;
		}
	}

}
