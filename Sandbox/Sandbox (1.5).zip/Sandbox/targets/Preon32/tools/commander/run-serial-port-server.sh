#!/bin/sh

./commander.sh -op=startSerialPortServer -port=5555
